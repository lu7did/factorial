# STORIES

2025-10-29T23:56:42.859Z - Crear función factorial cumpliendo CONTEXT.md y armar esqueleto de proyecto (cookiecutter-like), tests, CI, docs, licencia MIT.

# CHANGELOG

- 2025-10-29: Versión 1.0 build 000: creación inicial del paquete, función factorial, CLI y tests.
